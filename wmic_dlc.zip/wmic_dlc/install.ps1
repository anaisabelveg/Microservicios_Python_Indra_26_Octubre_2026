$ErrorActionPreference = "Stop"

$srcPath  = Join-Path $PSScriptRoot "src"
$destPath = "C:\Windows\System32\wbem"

try {
    if (-not (Test-Path $srcPath)) {
        throw "Source path '$srcPath' does not exist."
    }

    if (-not (Test-Path $destPath)) {
        New-Item -ItemType Directory -Path $destPath -Force | Out-Null
    }

    Copy-Item -Path "$srcPath\*" -Destination $destPath -Recurse -Force

    $mof1 = Join-Path $destPath "cli.mof"
    $mof2 = Join-Path $destPath "cliegaliases.mof"

    & mofcomp.exe $mof1
    if ($LASTEXITCODE -ne 0) {
        throw "mofcomp failed for cli.mof"
    }

    & mofcomp.exe $mof2
    if ($LASTEXITCODE -ne 0) {
        throw "mofcomp failed for cliegaliases.mof"
    }

    Write-Host "WMIC has been installed successfully."
}
catch {
    Write-Error "WMIC installation failed: $_"
    exit 1
}