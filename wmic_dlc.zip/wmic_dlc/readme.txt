Steps to install WMIC.exe

1. Make sure the script running has been enabled. If not, run below command in Administrative PowerShell, then select YES

Set-ExecutionPolicy RemoteSigned -Scope Process

2. under wmic_dlc folder, run below command in Administrative PowerShell:

.\install.ps1