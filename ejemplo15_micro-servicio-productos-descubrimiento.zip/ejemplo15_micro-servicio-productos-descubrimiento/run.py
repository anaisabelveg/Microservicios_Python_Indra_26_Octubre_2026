# Punto de entrada del servidor.

from app import create_app
from app.discovery_client import DiscoveryClient

app = create_app()

discovery = DiscoveryClient(
    service_name="micro-servicio-productos",
    host="127.0.0.1",
    port=8001
)

if __name__ == "__main__":
    
    discovery.start()
    
    try:
        # Arrancar el micro-servicio-productos en el puerto 8001
        app.run(host="127.0.0.1", port=8001, debug=True)
        
    finally:
        discovery.stop()

