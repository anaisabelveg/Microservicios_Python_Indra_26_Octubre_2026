# Crea y configura la aplicación Flask.

from flask import Flask
from app.routes import productos_bp
from app.errors import registrar_manejadores
from flasgger import Swagger

def create_app():
    app = Flask(__name__)
    
    # Configuracion de Swagger
    app.config["SWAGGER"] = {
        "title": "Microservicio de Productos",
        "uiversion": 3 # 3 es la version de Swagger UI para crear la interface grafica
    }
    Swagger(app)
    
    registrar_manejadores(app)
    
    app.register_blueprint(
        productos_bp, 
        url_prefix="/productos") # prefijo de las rutas /productos
    
    return app