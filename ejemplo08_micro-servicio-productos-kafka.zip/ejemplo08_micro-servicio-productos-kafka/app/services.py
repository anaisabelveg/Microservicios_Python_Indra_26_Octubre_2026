# Implementa las operaciones sobre la logica de negocio

from app.data import productos
from kafka import KafkaProducer
import json

TOPIC = "indra-cluster"

# creado y configurado el productor de Kafka
productor = KafkaProducer(
    bootstrap_servers=[
        "localhost:9092",
        "localhost:9093",
        "localhost:9094"
    ],
    value_serializer=lambda valor: json.dumps(valor, ensure_ascii=False).encode("utf-8"),
    acks="all"
)

def publicar_valoracion(producto, mensaje):
    comentario = {
        "producto": producto,
        "mensaje": mensaje
    }

    info_envio = productor.send(TOPIC, value=comentario)
    
    # Esperamos 10 segundos la confirmacion del broker para saber
    # si el mensaje se ha publicado correctamente
    confirmacion = info_envio.get(timeout=10)
    
    return{
        "comentario": comentario,
        "topic": confirmacion.topic,
        "particion": confirmacion.partition,
        "offset": confirmacion.offset
    }

def listar_productos():
    return list(productos.values())

def obtener_producto(producto_id):
    return productos.get(producto_id)

def crear_producto(descripcion, precio):
    nuevo_id = max(productos.keys(), default=0) + 1
    
    producto = {
        "id": nuevo_id, 
        "descripcion": descripcion, 
        "precio": precio
    }
    
    productos[nuevo_id] = producto
    return producto

def actualizar_producto(producto_id, descripcion, precio):
    # nos aseguramos que el producto existe
    if producto_id not in productos:
        return None
    
    producto = {
        "id": producto_id, 
        "descripcion": descripcion, 
        "precio": precio
    }
    
    productos[producto_id] = producto
    return producto

def eliminar_producto(producto_id):
     # nos aseguramos que el producto existe
    if producto_id not in productos:
        return None
    
    return productos.pop(producto_id, None)