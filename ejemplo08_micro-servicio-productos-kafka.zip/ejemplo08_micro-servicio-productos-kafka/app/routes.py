# Define los endpoints (ruta + metodo HTTP) REST.

from flask import jsonify, Blueprint, request
from app import services
from requests import RequestException

# Crear un Blueprint para que todas las rutas comiencen por /productos
productos_bp = Blueprint("productos", __name__)


# http://localhost:8001/productos/enviar/2/mensaje/Producto de buena calidad a precio asequible. Entrega rapida
@productos_bp.route("/enviar/<int:id_producto>/mensaje/<str:mensaje>", methods=["GET"])
def enviar(id_producto, mensaje):
    try:
        producto = services.obtener_producto(id_producto)
        
        if producto is None:
            return jsonify( {"error": "Producto no encontrado"} ), 404
        
        resultado = services.publicar_valoracion(producto, mensaje)
        
        return jsonify({
            "mensaje": "Comentario enviado a Kafka",
            **resultado
        }), 200
        
    except RequestException as error:
        return jsonify({
            "error": "No se pudo consultar el producto",
            "detalle": str(error)
        }), 502
        
    except Exception as error:
        return jsonify({
            "error": "No se pudo publicar la valoracion del producto en Kafka",
            "detalle": str(error)
        }), 502




# http://localhost:8001/productos/
@productos_bp.route("/", methods=["GET"])
def listar():
    return jsonify(services.listar_productos()), 200

# http://localhost:8001/productos/2
@productos_bp.route("/<int:producto_id>", methods=["GET"])
def obtener(producto_id):
    producto = services.obtener_producto(producto_id)
    
    if producto is None:
        return jsonify( {"error": "Producto no encontrado"} ), 404
    
    return jsonify(producto), 200

# crear el producto POST
# http://localhost:8001/productos/
@productos_bp.route("/", methods=["POST"])
def crear():
    # recuperar el json del cuerpo de la peticion
    datos = request.get_json()
  
    # datos es un JSON, **datos obtiene descripcion y precio de forma independiente
    producto = services.crear_producto(**datos)
    
    return jsonify(producto), 200

# modificar producto PUT
# http://localhost:8001/productos/2
@productos_bp.route("/<int:producto_id>", methods=["PUT"])
def actualizar(producto_id):
    # recuperar el json del cuerpo de la peticion
    datos = request.get_json()
    
    producto = services.obtener_producto(producto_id)
    
    if producto is None:
        return jsonify( {"error": "Producto no encontrado"} ), 404
    
    producto = services.actualizar_producto(producto_id, **datos)
    
    return jsonify(producto), 200

# eliminar producto DELETE
# http://localhost:8001/productos/2
@productos_bp.route("/<int:producto_id>", methods=["DELETE"])
def eliminar(producto_id):
    producto = services.eliminar_producto(producto_id)
    
    if producto is None:
        return jsonify( {"error": "Producto no encontrado"} ), 404
    
    return "", 200
