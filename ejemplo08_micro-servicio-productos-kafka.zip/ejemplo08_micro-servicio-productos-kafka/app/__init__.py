# Crea y configura la aplicación Flask.

from flask import Flask
from app.routes import productos_bp

def create_app():
    app = Flask(__name__)
    
    app.register_blueprint(
        productos_bp, 
        url_prefix="/productos") # prefijo de las rutas /productos
    
    return app