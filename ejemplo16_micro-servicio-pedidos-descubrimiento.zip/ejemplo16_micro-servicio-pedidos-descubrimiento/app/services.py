# Implementa las operaciones sobre la logica de negocio

import requests
from app.discovery_client import DiscoveryClient

# Crear la URL base de productos
# URL_PRODUCTOS = "http://127.0.0.1:8001/productos"

def crear_pedido(id_producto, cantidad):
    try:
        # Descubrir que instancias tengo disponibles   
        discovery = DiscoveryClient(
            service_name="micro-servicio-pedidos",
            host="127.0.0.1",
            port=8002
        )
        instancias = discovery.obtener_productos()
        
        if not instancias:
            return {
                "error": "El servicio productos no esta disponible"    
            }, 503
            
        # Elijo una instancia disponible
        instancia = instancias[0]
        
        URL_PRODUCTOS = (
            f"http://{instancia['host']}:{instancia['port']}/productos"
        )
        
        respuesta = requests.get(
            f"{URL_PRODUCTOS}/{id_producto}",
            timeout=5
        )
        
        if respuesta.status_code == 404:
            return {
                "error": "producto no encontrado"
            }, 404
            
        #respuesta.raise_for_status()    
        producto = respuesta.json()
        
    except requests.RequestException:
        return {
            "error": "Micro servicio de productos no esta disponible"
        }, 500
        
    pedido = {
        "producto": {
            "id": producto["id"],
            "descripcion": producto["descripcion"],
            "precio": producto["precio"]
        },
        "cantidad": cantidad
    }
    
    return pedido, 201
        