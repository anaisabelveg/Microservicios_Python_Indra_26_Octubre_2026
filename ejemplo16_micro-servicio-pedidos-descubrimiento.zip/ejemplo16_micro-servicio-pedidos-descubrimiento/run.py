# Punto de entrada del servidor.

from app import create_app
from app.discovery_client import DiscoveryClient

app = create_app()

discovery = DiscoveryClient(
    service_name="micro-servicio-pedidos",
    host="127.0.0.1",
    port=8002
)

if __name__ == "__main__":
    discovery.start()
    
    try:
        # Arrancar el micro-servicio-pedidos en el puerto 8002
        app.run(host="127.0.0.1", port=8002, debug=True)
        
    finally:
        discovery.stop()
