# Punto de entrada del servidor.

from app import create_app

app = create_app()

if __name__ == "__main__":
    # Para ver las metricas
    # localhost:8001/metrics
    
    # Arrancar el micro-servicio-productos en el puerto 8001
    # Para que funcione Prometheus hay que hacerlo sin debug
    app.run(host="127.0.0.1", port=8001)

