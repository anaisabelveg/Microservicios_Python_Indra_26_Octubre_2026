# Aqui configuramos Celery y las tareas que ejecutara el worker

import time
from celery import Celery

# Configuracion de Celery
celery = Celery(
    "pedidos",
    broker="redis://localhost:6379/0",  # indice 0 es donde va el broker
    backend="redis://localhost:6379/1"  # indice 1 es donde almacenamos los resultados
)


# Crear la tarea para que se ejecute de forma asincrona
@celery.task
def enviar_confirmacion(id_pedido, descripcion, cantidad):
    print(f"Preparando confirmacion del pedido {id_pedido}")
    
    # Simulamos una operacion que tarda 5 segundos
    time.sleep(5)
    
    print("Confirmacion del pedido preparada")
    print(f"Producto: {descripcion}")
    print(f"Cantidad: {cantidad}")
    
    return {
        "id_pedido": id_pedido,
        "estado": "confirmacion_preparada"
    }