# Define los endpoints REST.

from flask import jsonify, Blueprint
from app.services import crear_pedido

from app.tasks import enviar_confirmacion

pedidos_bp = Blueprint("pedidos", __name__)

# Crear un contador para generar el id_pedido
contador_pedidos = 1

# http://localhost:8002/crear/4/cantidad/100
@pedidos_bp.route("/crear/<int:id_producto>/cantidad/<int:cantidad>", methods=["GET"])
def crear(id_producto, cantidad):
    
    # acceso a la variable global para que solo haya una variable contador_pedidos
    global contador_pedidos
    
    if cantidad <= 0:
        return jsonify( {"error", "La cantidad debe ser mayor que 0"} ), 400
    
    pedido, codigo = crear_pedido(id_producto, cantidad)
    
    # Si hay un error
    if codigo != 201:
        return jsonify(pedido), codigo

    """ ****** Aqui empiezan las tareas en segundo plano ****** """
    # Asigno el id_pedido al pedido creado
    pedido["id_pedido"] = contador_pedidos
    contador_pedidos += 1
    
    # tarea = enviar_confirmacion() seria una llamada sincrona 
    # invocar a la tarea de forma asincrona enviar_confirmacion.delay
    # se envia la tarea al broker para que el worker la recoja y ejecute
    tarea = enviar_confirmacion.delay(
        pedido["id_pedido"],
        pedido["producto"]["descripcion"],
        pedido["cantidad"]
    )
    
    # Aqui retornamos el pedido creado
    return jsonify({
        "pedido": pedido,
        "tarea_celery": tarea.id,
        "mensaje":"Pedido creado y confirmacion en proceso"
    }), 201
    