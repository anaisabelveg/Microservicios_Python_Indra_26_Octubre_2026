# Implementa las operaciones sobre la logica de negocio

import requests

# Crear la URL base de productos
URL_PRODUCTOS = "http://127.0.0.1:8001/productos"

def crear_pedido(id_producto, cantidad):
    try:
        respuesta = requests.get(
            f"{URL_PRODUCTOS}/{id_producto}",
            timeout=5
        )
        
        if respuesta.status_code == 404:
            return {
                "error": "producto no encontrado"
            }, 404
            
        #respuesta.raise_for_status()    
        producto = respuesta.json()
        
    except requests.RequestException:
        return {
            "error": "Micro servicio de productos no esta disponible"
        }, 500
        
    pedido = {
        "producto": {
            "id": producto["id"],
            "descripcion": producto["descripcion"],
            "precio": producto["precio"]
        },
        "cantidad": cantidad
    }
    
    return pedido, 201
        