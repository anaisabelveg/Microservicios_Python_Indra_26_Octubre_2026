# Crea y configura la aplicación Flask.

from flask import Flask
from app.routes import pedidos_bp

def create_app():
    app = Flask(__name__)
    
    app.register_blueprint(pedidos_bp)
    
    return app