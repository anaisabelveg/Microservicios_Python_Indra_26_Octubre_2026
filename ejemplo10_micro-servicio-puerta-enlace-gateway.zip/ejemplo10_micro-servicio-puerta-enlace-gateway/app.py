# La puerta de enlace reenvia las peticiones HTTP

import requests
from flask import Flask, request, Response, jsonify

app = Flask(__name__)

# Direcciones de los microservicios
SERVICES = {
    "productos": "http://localhost:8001",
    "pedidos": "http://localhost:8002",
}

# Cabeceras que no deben reenviarse entre conexiones HTTP.
HOP_BY_HOP_HEADERS = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade",
    "host",
    "content-length",
}

def enrutar(service_name, path=""):
    # Reenviar la peticion al microservicio correspondiente
    base_url = SERVICES[service_name]
    url = f"{base_url}/{path}"
    
    # Crear un diccionario con las cabeceras que recibimos en la peticion a la puerta de enlace
    # pero excluimos las que tengo declaradas en HOP_BY_HOP_HEADERS
    headers = {
        key: value for key, value in request.headers if key.lower() not in HOP_BY_HOP_HEADERS
    }
    
    try:
        response = requests.request(
            method=request.method,
            url=url,
            params=request.args,
            headers=headers,
            data=request.get_data(),
            cookies=request.cookies,
            timeout=10,
            allow_redirects=False
        )
        
        # Obtener las cabeceras de la respuesta en una lista de tuplas
        response_headers = [ (key, value) for key, value in response.raw.headers.items() 
                                if key.lower() not in HOP_BY_HOP_HEADERS and key.lower() != "set-cookie"]
        
        # Conservar las cookies emitidas por el servicio de destino
        response_headers.extend( ("Set-Cookie", value)  for value in response.raw.headers.getlist("Set-Cookie"))
        
        return Response(
            response.content,
            status=response.status_code,
            headers=response_headers
        )
        
    except requests.RequestException:
        return jsonify({
            "error": f"El microservicio {service_name} no esta disponible" 
        }), 502


''' ****************** Productos ************** '''
# http://localhost:8090/api/prods/productos
@app.route(
    "/api/prods",
    defaults={"path": ""},
    methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"]
)

# http://localhost:8090/api/prods/productos/3
@app.route(
    "/api/prods/<path:path>",
    methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"]   
)
def productos(path):
    # enrutamos al micro-servicio-productos
    return enrutar("productos", path)


''' ****************** Pedidos ************** '''
# http://localhost:8090/api/pedidos/crear/4/cantidad/100 (GET)
@app.route(
    "/api/pedidos/<path:path>",
    methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"]   
)
def pedidos(path):
    # enrutamos al micro-servicio-pedidos
    return enrutar("pedidos", path)



if __name__ == "__main__":
    # Arrancar la puerta de enlace en el puerto 8090
    app.run(host="127.0.0.1", port=8090, debug=True)