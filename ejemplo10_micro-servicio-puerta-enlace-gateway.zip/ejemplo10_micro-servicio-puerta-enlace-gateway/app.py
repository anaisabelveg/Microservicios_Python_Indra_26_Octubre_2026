# La puerta de enlace reenvia las peticiones HTTP


# Direcciones de los microservicios
SERVICES = {
    "productos": "http://localhost:8001",
    "pedidos": "http://localhost:8002",
}