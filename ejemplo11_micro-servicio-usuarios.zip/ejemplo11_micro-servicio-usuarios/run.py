# Punto de entrada del servidor.

from app import create_app

app = create_app()

if __name__ == "__main__":
    # Arrancar el micro-servicio-usuarios en el puerto 8004
    app.run(host="127.0.0.1", port=8004, debug=True)