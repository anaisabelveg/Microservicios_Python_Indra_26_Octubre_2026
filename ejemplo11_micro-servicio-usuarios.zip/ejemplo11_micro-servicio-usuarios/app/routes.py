# Define los endpoints REST.

from flask import Blueprint, jsonify, request
from app.services import authenticate, crear_token
from app.data import user_repository

api = Blueprint("api", __name__)

# http://localhost:8004/auth/login (POST)
@api.post("/auth/login")
def login():
    # recuperamos el JSON del cuerpo de la peticion
    data = request.get_json()
    
    # Si no recibo los datos retorno un error
    if not isinstance(data, dict):
        return jsonify({
            "error": "Debes proporcionar username y password"
        }), 400
        
    username = data.get("username")
    password = data.get("password")
    
    # Procedemos a autenticar al usuario
    user = authenticate(username, password)
    
    if user is None:
        return jsonify({
            "error": "Usuario o password incorrectas"    
        }), 401
        
    # El usuario esta autenticado retornar el JWT
    return jsonify({
        "access_token": crear_token(user),
        "token_type": "Bearer",
        "user": user.to_dict()
    }), 200
    

# http://localhost:8004/listar (GET)
@api.get("/listar")
def lista_usuarios():
    return jsonify({
        "users": [
            user.to_dict() for user in user_repository.get_all()
        ]
    }), 200