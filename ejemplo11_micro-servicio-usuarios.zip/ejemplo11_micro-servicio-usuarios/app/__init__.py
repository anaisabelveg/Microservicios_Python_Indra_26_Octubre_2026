# Crea y configura la aplicación Flask.

from flask import Flask, jsonify
from flask_jwt_extended import JWTManager
from app.routes import api
import os
from datetime import timedelta

def create_app():
    app = Flask(__name__)
    
    app.config.from_mapping(
        JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY"),
        JWT_ACCESS_TOKEN_EXPIRES=timedelta(hours=1)
    )
    
    JWTManager(app)
    
    app.register_blueprint(api)
    
    return app