# Implementa las operaciones sobre la logica de negocio
# Aqui trabajamos la autenticacion

from app.data import user_repository
from flask_jwt_extended import create_access_token

def authenticate(username, password):
    # Devuelve el usuario si las credenciales son correctas    
    user = user_repository.get_by_username(username)
    
    # Comprobar si existe el user y verificar el password
    if user and user.verificar_password(password):
        return user
    return None
    
    
def crear_token(user):
    # Genera un JWT con los datos del usuario
    
    return create_access_token(
        identity=user.username,
        additional_claims={
            "roles": user.roles
        }
    )