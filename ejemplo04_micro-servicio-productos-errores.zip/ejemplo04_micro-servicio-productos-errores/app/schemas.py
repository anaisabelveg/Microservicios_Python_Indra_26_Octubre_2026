# definir los esquemas de entrada y salida con las reglas de validacion

from marshmallow import Schema, fields, validate

class ProductoEntradaSchema(Schema):
    ''' Validar los datos recibidos al crear o actualizar un producto '''
    # fields.String o fields.Str es lo mismo
    descripcion = fields.String(
        required=True,
        error_messages= {
            "required": "Descripcion obligatoria",
            "invalid": "Debe ser una cadena de texto"} ,
        validate = [validate.Length(min=3, error="Longitud minima 3 caracteres"),
                   validate.Length(max=20, error="Longitud maxima 20 caracteres")]
    )
    
    precio = fields.Float(
        required=True,
        error_messages= {
            "required": "Precio obligatorio",
            "invalid": "Debe ser numerico"} ,
        validate = validate.Range(min=0, error="Debe ser numero positivo")
    )


class ProductoSalidaSchema(Schema):
    ''' Validar todos los datos que exponemos desde el API Rest '''
    id = fields.Integer(required=True)
    descripcion = fields.String(required=True)
    precio = fields.Float(required=True)
    
# Crear una instancia de cada clase
entrada_schema = ProductoEntradaSchema()
salida_schema = ProductoSalidaSchema()
salida_lista_schema = ProductoSalidaSchema(many=True)  # crear el esquema para una lista de productos