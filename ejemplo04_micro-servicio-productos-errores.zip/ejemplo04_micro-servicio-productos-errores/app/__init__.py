# Crea y configura la aplicación Flask.

from flask import Flask
from app.routes import productos_bp
from app.errors import registrar_manejadores

def create_app():
    app = Flask(__name__)
    
    # registramos los manejadores de error al crear la aplicacion
    registrar_manejadores(app)
    
    app.register_blueprint(
        productos_bp, 
        url_prefix="/productos") # prefijo de las rutas /productos
    
    return app