# Contiene los seis productos iniciales.
# Creamos un diccionario 
productos = {
    1: {"id": 1, "descripcion": "Teclado mecánico", "precio": 59.90},
    2: {"id": 2, "descripcion": "Ratón inalámbrico", "precio": 24.50},
    3: {"id": 3, "descripcion": "Monitor 27 pulgadas", "precio": 219.99},
    4: {"id": 4, "descripcion": "Webcam HD", "precio": 39.95},
    5: {"id": 5, "descripcion": "Auriculares USB", "precio": 34.90},
    6: {"id": 6, "descripcion": "Alfombrilla gaming", "precio": 14.99},
}