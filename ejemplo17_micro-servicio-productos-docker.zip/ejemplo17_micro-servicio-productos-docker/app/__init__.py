# Crea y configura la aplicación Flask.

from flask import Flask


def create_app():
    app = Flask(__name__)

    from app.routes import productos_bp

    app.register_blueprint(
        productos_bp,
        url_prefix="/productos",
    )

    return app