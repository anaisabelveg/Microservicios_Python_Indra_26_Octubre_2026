# Define los endpoints REST.

import math

from flask import Blueprint, jsonify, request

from app import services

productos_bp = Blueprint("productos", __name__)


def validar_datos(datos):
    if not isinstance(datos, dict):
        return None, "El cuerpo debe ser un objeto JSON"

    descripcion = datos.get("descripcion")
    precio = datos.get("precio")

    if not isinstance(descripcion, str) or not descripcion.strip():
        return None, "La descripcion es obligatoria"

    # bool es una subclase de int en Python, por eso lo excluimos.
    if isinstance(precio, bool) or not isinstance(precio, (int, float)):
        return None, "El precio debe ser numerico"

    if not math.isfinite(precio) or precio < 0:
        return None, "El precio debe ser finito y no negativo"

    return {
        "descripcion": descripcion.strip(),
        "precio": precio,
    }, None


# GET /productos
@productos_bp.route("/", methods=["GET"])
def listar():
    return jsonify(services.listar_productos()), 200


# GET /productos/1
@productos_bp.route("/<int:producto_id>", methods=["GET"])
def obtener(producto_id):
    producto = services.obtener_producto(producto_id)

    if producto is None:
        return jsonify({"error": "Producto no encontrado"}), 404

    return jsonify(producto), 200


# POST /productos
@productos_bp.route("/", methods=["POST"])
def crear():
    datos, error = validar_datos(request.get_json(silent=True))

    if error:
        return jsonify({"error": error}), 400

    producto = services.crear_producto(**datos)

    return jsonify(producto), 201


# PUT /productos/1
@productos_bp.route("/<int:producto_id>", methods=["PUT"])
def actualizar(producto_id):
    if services.obtener_producto(producto_id) is None:
        return jsonify({"error": "Producto no encontrado"}), 404

    datos, error = validar_datos(request.get_json(silent=True))

    if error:
        return jsonify({"error": error}), 400

    producto = services.actualizar_producto(producto_id, **datos)

    return jsonify(producto), 200


# DELETE /productos/1
@productos_bp.route("/<int:producto_id>", methods=["DELETE"])
def eliminar(producto_id):
    producto = services.eliminar_producto(producto_id)

    if producto is None:
        return jsonify({"error": "Producto no encontrado"}), 404

    return "", 204