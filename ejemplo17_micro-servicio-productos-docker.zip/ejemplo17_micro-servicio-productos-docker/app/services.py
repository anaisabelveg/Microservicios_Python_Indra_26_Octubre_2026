# Implementa las operaciones sobre productos. 
# La logica de negocio

from app.data import productos


def listar_productos():
    return list(productos.values())


def obtener_producto(producto_id):
    return productos.get(producto_id)


def crear_producto(descripcion, precio):
    nuevo_id = max(productos.keys(), default=0) + 1

    producto = {
        "id": nuevo_id,
        "descripcion": descripcion,
        "precio": precio,
    }

    productos[nuevo_id] = producto
    return producto


def actualizar_producto(producto_id, descripcion, precio):
    if producto_id not in productos:
        return None

    producto = {
        "id": producto_id,
        "descripcion": descripcion,
        "precio": precio,
    }

    productos[producto_id] = producto
    return producto


def eliminar_producto(producto_id):
    return productos.pop(producto_id, None)