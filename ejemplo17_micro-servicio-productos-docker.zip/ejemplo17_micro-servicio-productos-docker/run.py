# Punto de entrada del servidor.

from app import create_app

app = create_app()

if __name__ == "__main__":
    # Arrancamos el micro-servicio-productos en el puerto 8001
    app.run(host="127.0.0.1", port=8001, debug=True)