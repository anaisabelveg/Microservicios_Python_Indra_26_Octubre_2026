# python3 -m pip install Flask
# pip install --upgrade pip

from flask import Flask, jsonify

# crear la aplicacion
app = Flask(__name__) 

# http://localhost:5000/hola
# asocia una URL y un metodo HTTP a una función
@app.route("/hola", methods=["GET"])
def hola():
    # Queremos que la respuesta sea en formao JSON
    return jsonify( {"mensaje": "Bienvenidos al curso de microservicios con Python y Flask"} )

# Arrancar la aplicacion
if __name__ == "__main__":
    # arrancar el servidor de desarrollo
    app.run(debug=True)
