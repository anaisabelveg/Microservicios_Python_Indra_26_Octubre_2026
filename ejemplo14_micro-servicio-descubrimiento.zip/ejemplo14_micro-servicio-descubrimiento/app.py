# Este servidor permite registrar múltiples instancias de un mismo microservicio, 
# enviar heartbeats, consultar instancias y limpiar automáticamente los registros caducados.

'''
    ¿Qué hace este código?
        Asigna un identificador único a cada instancia.
        Mantiene las instancias en un registro compartido dentro del proceso.
        Usa un bloqueo para proteger las operaciones concurrentes sobre el diccionario.
        Elimina las instancias cuyo último heartbeat supera los 30 segundos.
        Permite descubrir todas las instancias disponibles de un servicio lógico, por ejemplo users-service.
        
    El mecanismo de lease y heartbeat sigue el mismo principio general que Eureka, aunque los intervalos 
    de este ejemplo son más cortos para facilitar las pruebas. 
    Eureka utiliza habitualmente renovaciones cada 30 segundos y un umbral de expiración cercano a los 90 segundos. 
'''


from datetime import datetime, timezone
from threading import RLock
from uuid import uuid4

from flask import Flask, jsonify, request

app = Flask(__name__)

# Registro en memoria, protegido para accesos concurrentes.
registry = {}
registry_lock = RLock()

LEASE_SECONDS = 30


def utc_now():
    return datetime.now(timezone.utc)


def serialize_instance(instance):
    return {
        **instance,
        "last_heartbeat": instance["last_heartbeat"].isoformat(),
    }


def cleanup_expired():
    """Elimina instancias que no han renovado su lease."""
    now = utc_now()

    with registry_lock:
        expired = [
            instance_id
            for instance_id, instance in registry.items()
            if (now - instance["last_heartbeat"]).total_seconds()
            > LEASE_SECONDS
        ]

        for instance_id in expired:
            del registry[instance_id]


@app.get("/health")
def health():
    return jsonify({"status": "UP"})


@app.post("/register")
def register():
    data = request.get_json(silent=True) or {}

    service_name = data.get("service_name")
    host = data.get("host")
    port = data.get("port")

    if not service_name or not host or port is None:
        return jsonify({
            "error": "service_name, host y port son obligatorios"
        }), 400

    # Evita aceptar puertos inválidos o valores booleanos.
    if isinstance(port, bool) or not isinstance(port, int):
        return jsonify({"error": "port debe ser un entero"}), 400

    if not 1 <= port <= 65535:
        return jsonify({"error": "port fuera de rango"}), 400

    if not all(isinstance(value, str) for value in
               (service_name, host)):
        return jsonify({"error": "service_name y host deben ser texto"}), 400

    if not service_name.strip() or not host.strip():
        return jsonify({"error": "service_name y host no pueden estar vacíos"}), 400

    instance_id = str(uuid4())

    instance = {
        "instance_id": instance_id,
        "service_name": service_name,
        "host": host,
        "port": port,
        "status": "UP",
        "last_heartbeat": utc_now(),
    }

    with registry_lock:
        registry[instance_id] = instance

    return jsonify(serialize_instance(instance)), 201


@app.put("/heartbeat/<instance_id>")
def heartbeat(instance_id):
    cleanup_expired()

    with registry_lock:
        instance = registry.get(instance_id)

        if instance is None:
            return jsonify({"error": "Instancia no registrada"}), 404

        instance["last_heartbeat"] = utc_now()
        instance["status"] = "UP"

        return jsonify({
            "instance_id": instance_id,
            "status": "UP",
        })


@app.delete("/register/<instance_id>")
def deregister(instance_id):
    with registry_lock:
        instance = registry.pop(instance_id, None)

    if instance is None:
        return jsonify({"error": "Instancia no encontrada"}), 404

    return "", 204


@app.get("/services")
def list_services():
    cleanup_expired()

    with registry_lock:
        services = {}

        for instance in registry.values():
            name = instance["service_name"]
            services.setdefault(name, []).append(
                serialize_instance(instance)
            )

    return jsonify(services)


@app.get("/services/<service_name>")
def discover_service(service_name):
    cleanup_expired()

    with registry_lock:
        instances = [
            serialize_instance(instance)
            for instance in registry.values()
            if instance["service_name"] == service_name
            and instance["status"] == "UP"
        ]

    return jsonify({
        "service_name": service_name,
        "instances": instances,
        "count": len(instances),
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8761, debug=False)
