# Crea y configura la aplicación Flask.
