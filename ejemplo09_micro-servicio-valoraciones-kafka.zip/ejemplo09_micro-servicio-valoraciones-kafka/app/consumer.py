# Este es el consumidor o subscriptor de Kafka
# Cuando llega un comentario, lo convietira de JSON a un diccionario y lo imprimira

import json
from kafka import KafkaConsumer

def consumir_valoraciones():
    consumidor = KafkaConsumer(
        "indra-cluster",
        bootstrap_servers=[
            "localhost:9092",
            "localhost:9093",
            "localhost:9094"
        ],
        group_id="grupo1",
        auto_offset_reset="earliest",
        enable_auto_commit=True,
        value_deserializer=lambda valor: valor.decode("utf-8")        
    )
    
    print("El Subscriptor ya esta conectado a Kafka")
    print("Esperando comentarios ...")
    
    try:
        for evento in consumidor:
            try:
                comentario = json.loads(evento.value)
                
                print("------ Nueva valoracion recibida ------")
                print(f"Producto: {comentario["producto"]}")
                print(f"Valoracion: {comentario["mensaje"]}")
                print(f"Topic: {evento.topic}")
                print(f"Particion: {evento.partition}")
                print(f"Offset: {evento.offset}")
                
            except Exception as error:    
                print(f"Error: {error}")
        
    finally:
        consumidor.close()