# Define los endpoints (ruta + metodo HTTP) REST.

from flask import jsonify, Blueprint, request
from app import services

# importar marshmallow y los esquemas
from marshmallow import ValidationError
from app.schemas import entrada_schema, salida_schema, salida_lista_schema

productos_bp = Blueprint("productos", __name__)

# http://localhost:8001/productos/
@productos_bp.route("/", methods=["GET"])
def listar():
    productos = services.listar_productos()
    resultado = salida_lista_schema.dump(productos)
    # Tambien funciona con many=True
    # resultado = salida_schema.dump(productos, many=True)
    return jsonify(resultado), 200


# http://localhost:8001/productos/2
@productos_bp.route("/<int:producto_id>", methods=["GET"])
def obtener(producto_id):
    producto = services.obtener_producto(producto_id)
    
    if producto is None:
        return jsonify( {"error": "Producto no encontrado"} ), 404
    
    return jsonify(salida_schema.dump(producto)), 200



# crear el producto POST
# http://localhost:8001/productos/
@productos_bp.route("/", methods=["POST"])
def crear():
    datos, errores = validar_entrada()
  
    if errores:
        return jsonify( {"errores": errores} ), 400
    
    producto = services.crear_producto(**datos)
    
    return jsonify(producto), 201


# modificar producto PUT
# http://localhost:8001/productos/2
@productos_bp.route("/<int:producto_id>", methods=["PUT"])
def actualizar(producto_id):
    datos, errores = validar_entrada()
  
    if errores:
        return jsonify( {"errores": errores} ), 400
    
    producto = services.obtener_producto(producto_id)
    
    if producto is None:
        return jsonify( {"error": "Producto no encontrado"} ), 404
    
    producto = services.actualizar_producto(producto_id, **datos)
    
    return jsonify(producto), 200

# eliminar producto DELETE
# http://localhost:8001/productos/2
@productos_bp.route("/<int:producto_id>", methods=["DELETE"])
def eliminar(producto_id):
    producto = services.eliminar_producto(producto_id)
    
    if producto is None:
        return jsonify( {"error": "Producto no encontrado"} ), 404
    
    return "", 200


def validar_entrada():
    # recuperar el json del cuerpo de la peticion
    datos = request.get_json()
    
    # Comprobar que el JSON existe
    if datos is None:
        return None, {"error": ["Se necesita un Json con descripcion y precio"]}
    
    try:
        # comprobar que los datos cumplen con las reglas de validacion
        datos_validados = entrada_schema.load(datos)
        return datos_validados, None  # None porque no hay errores de validacion
    except ValidationError as error:
        # Al no cumplirse las reglas de validacion, se ha producido un error que capturamos aqui
        # retornar los mensajes de error
        return None, error.messages